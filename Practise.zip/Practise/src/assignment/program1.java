package assignment;

import java.util.LinkedList;
import java.util.List;

class Person {
	    String name, surname, phone, email, place;
	    public Person(String name, String surname, String phone, String email, String place) {
	        this.name = name;
	        this.surname = surname;
	        this.phone = phone;
	        this.email = email;
	        this.place = place;
	    }
	}

	public class program1 {
	    public static void main(String[] args) {
	        List<Person> list = new LinkedList<>();
	        Person p1 = new Person("kayal", "R", "987665432", "kayal@gmail.com", "Chennai");
	        Person p2 = new Person("kaviya", "Raman", "8765432190", "kaviya@gmail.com", "Bangalore");
	        Person p3 = new Person("swetha", "K R", "9123456789", "swetha@gmail.com", "Coimbatore");
	        list.add(p1);
	        list.add(p2);
	        list.add(p3);
	        System.out.println("Telephone Directory Details");
	        for (Person p : list) {
	            System.out.println(p.name + " " + p.surname + " , " + p.phone + " , " + p.email + "  " + p.place);
	        }
	    }
	
}
