package assignment;

import java.util.ArrayList;

public class program2 {
	    public static void main(String[] args) {
	        int sqFeet = 500;
	        int pricePerSqFt = 2500;

	        double basePrice = sqFeet * pricePerSqFt;
	        double regTax = 0.08 * basePrice;
	        double gst = 0.03 * basePrice;
	        double total = basePrice + regTax + gst;

	        ArrayList<String> steps = new ArrayList<>();
	        steps.add("Flat Area: " + sqFeet + " Sq Ft");
	        steps.add("Price per Sq Ft: ₹" + pricePerSqFt);
	        steps.add("Base Price: ₹" + basePrice);
	        steps.add("Registration Tax (8%): ₹" + regTax);
	        steps.add("GST (3%): ₹" + gst);
	        steps.add("Total Price to Pay: ₹" + total);

	        System.out.println("=== Real Estate Calculation ===");
	        for (String s : steps) {
	            System.out.println(s);
	        }
	    }
	
}
