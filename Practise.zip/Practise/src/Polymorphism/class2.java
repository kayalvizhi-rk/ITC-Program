package Polymorphism;

public class class2 {
public static void main(String[] args) {
	System.out.println(10+20);
	System.out.println("san"+"rani");
	System.out.println("kay"+10);
	System.out.println("kayal"+10+"vizhi");
}
}
