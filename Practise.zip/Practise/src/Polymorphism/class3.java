package Polymorphism;

class shape{
	void draw() {
		System.out.println("no shape");
	}
}
class triangle extends shape{
	void draw() {
		System.out.println("draw triangle");
	}
}
class rectangle extends shape{
	void draw() {
		System.out.println("draw rectangle");
	}
}
class circle extends shape{
	void draw() {
		System.out.println("draw circle");
	}
}



public class class3 {
public static void main(String[] args) {
	shape obj=new circle();
	shape obj1=new triangle();
	shape obj2=new rectangle();
	
	obj.draw();
	obj1.draw();
	obj2.draw();
	
	
}
}
