package constructor;

public class class1 {
	void m1() {
		System.out.println("m1 method");
	}
	class1() {
		System.out.println("0 age constructor");
	}
	class1(int a) {
		System.out.println("1 age constructor");
		System.out.println(a+ " 1 age constructor ");
	}
    public static void main(String[] args) {
    	
    	class1 t1=new class1(10);
    	t1.m1();
    	
    	//default constructor--> so only it print 0 age constructor
    	class1 t=new class1();
    	t.m1();
    }
}
