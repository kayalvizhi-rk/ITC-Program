package constructor;

public class class3 {
	int eid;
	String ename;
	float esal;
	
	class3(){
		eid=64035;
		ename="kayal";
		esal=27000;
	}
	void disp() {
		System.out.println("Emp ID:"+eid);
		System.out.println("Emp name:"+ename);
		System.out.println("Emp salary:"+esal);
	}
	public static void main(String[] args) {
		class3 e=new class3();
		e.disp();
	}

}
