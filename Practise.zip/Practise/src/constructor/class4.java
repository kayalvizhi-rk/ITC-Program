package constructor;

public class class4 {
	int eid;
	String ename;
	float esal;
	
	class4(int eid,String ename,float esal){
		this.eid=eid;
		this.ename=ename;
		this.esal=esal;
	}
	void disp() {
		System.out.println("Emp ID:"+eid);
		System.out.println("Emp name:"+ename);
		System.out.println("Emp salary:"+esal);
	}
	public static void main(String[] args) {
		class4 e=new class4(64035,"kayal",27000);
		e.disp();
		class4 e1=new class4(64042,"kaviya",27000);
		e1.disp();
	}

}
