package Instanceblocks;

public class class1 {
	class1(){
		System.out.println("0 arg construct");
	}
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) {
		new class1();    ///without creating the object
	}

}
