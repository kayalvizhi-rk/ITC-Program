package Instanceblocks;

public class class2 {
	class2(){
		System.out.println("0 arg construct");
	}
	class2(int a){
		System.out.println("1 arg construct");
	}
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) {
		new class2(); 
		new class2(10);
	}

}
