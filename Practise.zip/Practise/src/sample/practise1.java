package sample;



public class practise1 {
	public static void main(String[] args) {
		int a=25;
		int b=25;
		System.out.println(a+b);

	}
}
