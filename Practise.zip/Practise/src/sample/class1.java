package sample;
import java.util.*;
public class class1 {
	public static double age() {
		Scanner sc = new Scanner(System.in);
		boolean valid =false;
		double input=0;
		while(!valid) {
			System.out.println("Enter your age <100 : ");
			input =sc.nextDouble();
			if(input>0 && input<100) {
				valid =true;
				System.out.println("This is correct age");
			}
			else {
				System.out.println("Sorry Invalid input");
			}
		}
		return input;
	}
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a = age();
		System.out.println(a);
	}
 
}