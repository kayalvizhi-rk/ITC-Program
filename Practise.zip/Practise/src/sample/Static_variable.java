package sample;

public class Static_variable {
	static int a=1000;
	static int b=2000;
	public static void main(String[] args) {
		System.out.println(Static_variable.a);
		System.out.println(Static_variable.b);
		Static_variable t=new Static_variable();
		t.m1();
		//System.out.println(a);
	}
	void m1() {
		System.out.println(Static_variable.a);
		System.out.println(Static_variable.b);
	}

}
