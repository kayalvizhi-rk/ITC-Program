package encapsulation;

public class class4 {
	public static void main(String[] args) {
		class3 car=new class3("Toyota",2022);
		System.out.println("Model:"+car.getModel());
		System.out.println("year:"+car.getYear());
	}

}
