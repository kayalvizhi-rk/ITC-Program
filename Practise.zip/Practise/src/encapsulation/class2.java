package encapsulation;

public class class2 {
public static void main(String[] args) {
	class1 person=new class1();
	person.setName("kayal");
	person.setAge(0);
	System.out.println("Name:"+person.getName());
	System.out.println("Age:"+person.getAge());
	
}
}
