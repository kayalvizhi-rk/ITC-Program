package method;

public class class1 {
	void m1() {
		System.out.println("m1 method");        ///instance method we need to create obj
	}
	static void m2() {
		System.out.println("m2 method");      ///static method we need not to create obj
	}
	
	public static void main(String[] args) {
		class1 t=new class1();
		t.m1();
		class1.m2();
	}
}
