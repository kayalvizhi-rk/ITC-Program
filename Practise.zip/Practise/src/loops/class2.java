package loops;

public class class2 {
	public static void main(String[] args) {
		int n=1;
		switch(n++){
		case 1:
			System.out.println("1");
		break;
		case 2:
			System.out.println("2");
		break;
		default:
			System.out.println("3");
		}
		
		}
	}


