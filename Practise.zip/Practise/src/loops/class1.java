package loops;

public class class1 {
	public static void main(String[] args) {
		int i=76;
		if(i==56) {
			System.out.println("f");
		}
		else if(i==0) {
			System.out.print("t");
		}
		else {
			System.out.println("true");
		}
	}

}
