package Inheritance;
class Q{
	Q(){
		System.out.println("parent 0 arg constructor");
	}
}

public class class2 extends Q{
	class2(){
		
		this(10);
		System.out.println("child 0 arg constructor");
	}
	class2(int a){
		super();
		System.out.println("child 1 arg constructor");
	}
	public static void main(String[] args) {
		new class2();
	}


}
