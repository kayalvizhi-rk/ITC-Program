package static_block;

public class class1 {
	{
		System.out.println("instance block 1");
	}
	{
		System.out.println("instance block 2");
	}
	static{
		System.out.println("static block 1");
	}
	static{
		System.out.println("static block 2");
	}
	class1(){
		System.out.println("0 arg constructor");
	}
	class1(int a){
		System.out.println("1 arg constructor");
	}
	public static void main(String[] args) {
		new class1();
		new class1(10);
	}
	
	// 1st static will print
	// 2nd instance bloce will print
	// then constructor 1 will print after that 
	//--(each constructor object will be created so only it print the instance block)
	/*output
	 * static block 1
		static block 2
		instance block 1
		instance block 2
		0 arg constructor  --constructor
		instance block 1   -- object for constructor
		instance block 2
		1 arg constructor

	 */

}
