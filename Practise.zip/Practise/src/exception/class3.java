package exception;

public class class3 {
	public static void main(String[] args) {
		try {
			int[] myNum= {1,2,4};
			System.out.println(myNum[10]);
		}
		catch(Exception e) {
			System.out.println("something went wrong");
		}
		finally {
			System.out.println("The 'try catch' is finished");
		}
	}

}
