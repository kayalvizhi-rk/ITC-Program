package TestNG;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
public class checkbox {
    WebDriver driver;
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://the-internet.herokuapp.com/checkboxes");
    }
    @Test
    public void verifyCheckboxes() {
        // Locate checkboxes
        WebElement checkbox1 = driver.findElements(By.cssSelector("input[type='checkbox']")).get(0);
        WebElement checkbox2 = driver.findElements(By.cssSelector("input[type='checkbox']")).get(1);
        // Verify initial states
        Assert.assertFalse(checkbox1.isSelected(), "Checkbox 1 should be unchecked initially");
        Assert.assertTrue(checkbox2.isSelected(), "Checkbox 2 should be checked initially");
        // Click checkbox1 to select it
        checkbox1.click();
        Assert.assertFalse(checkbox1.isSelected(), "Checkbox 1 should now be checked");
        // Click checkbox2 to deselect it
        checkbox2.click();
        Assert.assertTrue(checkbox2.isSelected(), "Checkbox 2 should now be unchecked");
    }
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

