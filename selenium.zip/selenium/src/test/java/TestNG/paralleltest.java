package TestNG;

import org.testng.annotations.Test;
public class paralleltest {
    @Test
    public void test1() {
        System.out.println("Test1 | Thread: " + Thread.currentThread().getId());
    }
    @Test
    public void test2() {
        System.out.println("Test2 | Thread: " + Thread.currentThread().getId());
    }
    @Test
    public void test3() {
        System.out.println("Test3 | Thread: " + Thread.currentThread().getId());
    }
}



