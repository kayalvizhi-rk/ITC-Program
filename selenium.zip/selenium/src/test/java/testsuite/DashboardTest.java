package testsuite;

import org.testng.annotations.Test;

public class DashboardTest {
  @Test
  public void testDashboardLoad() {
	  System.out.println("Dashboard loaded");
  }
}
