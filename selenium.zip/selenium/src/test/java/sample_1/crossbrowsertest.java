package sample_1;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
public class crossbrowsertest extends Testbase {
    @Parameters("browser")
    @BeforeMethod
    public void setUp(@Optional("chrome") String browser) {
        driver = setupDriver(browser);
    }
    @Test
    public void testGoogleSearch() {
        driver.get("https://www.google.com");
        String title = driver.getTitle();
        System.out.println("Title on " + driver.getClass().getSimpleName() + ": " + title);
        assert title.contains("Google");
    }
