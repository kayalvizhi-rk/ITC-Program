package test_double;

public class Dummyemailservice implements mailservice {
	@Override
public void sendEmail(String message) {
	//dummy
}
}
