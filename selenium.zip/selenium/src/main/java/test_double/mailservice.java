package test_double;

public interface mailservice {
	void sendEmail(String message);

}
