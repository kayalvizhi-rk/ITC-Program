package test_double;

import org.testng.Assert;
import org.testng.annotations.Test;

public class reportservicetest {
	@Test
public void testGenerateReport() {
	mailservice dummyemail= new Dummyemailservice();
	reportservice reportService=new reportservice(dummyemail);
	String result=reportService.generateReport();
	Assert.assertEquals(result, "Report Generated");
}
}
