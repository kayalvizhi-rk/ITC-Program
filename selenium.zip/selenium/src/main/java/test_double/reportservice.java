package test_double;

public class reportservice {
	private mailservice emailservice;
	public reportservice(mailservice emailService) {
		this.emailservice=emailService;
	}
	public String generateReport() {
		return "Report generated";
	}

}
